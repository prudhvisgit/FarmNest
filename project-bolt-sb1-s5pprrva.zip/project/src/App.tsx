import React from 'react';
import { Plane as Plant, Users, ShoppingBasket, Brain, LineChart, Shield } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      {/* Hero Section */}
      <header className="relative">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80"
            alt="Farm landscape"
            className="w-full h-[600px] object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
              Empowering Farmers with
              <span className="text-green-400"> AI-Driven</span> Solutions
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-xl text-gray-200">
              Connect directly with customers, optimize your yields, and maximize your profits using cutting-edge artificial intelligence.
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <button className="bg-green-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-600 transition">
                Join as Farmer
              </button>
              <button className="bg-white text-green-700 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
                Shop Products
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900">Why Choose Our Platform?</h2>
            <p className="mt-4 text-lg text-gray-600">Revolutionizing agriculture through technology and direct market access</p>
          </div>

          <div className="mt-20 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <Brain className="w-8 h-8 text-green-500" />,
                title: "AI-Powered Insights",
                description: "Get personalized recommendations for crop management and market timing"
              },
              {
                icon: <Users className="w-8 h-8 text-green-500" />,
                title: "Direct Customer Connection",
                description: "Sell directly to consumers and maximize your profits"
              },
              {
                icon: <Plant className="w-8 h-8 text-green-500" />,
                title: "Crop Optimization",
                description: "Optimize your yields with data-driven farming techniques"
              },
              {
                icon: <ShoppingBasket className="w-8 h-8 text-green-500" />,
                title: "Digital Marketplace",
                description: "Access a wide network of buyers for your produce"
              },
              {
                icon: <LineChart className="w-8 h-8 text-green-500" />,
                title: "Market Analytics",
                description: "Make informed decisions with real-time market data"
              },
              {
                icon: <Shield className="w-8 h-8 text-green-500" />,
                title: "Secure Transactions",
                description: "Safe and transparent payment processing"
              }
            ].map((feature, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl hover:shadow-lg transition">
                <div className="bg-white w-16 h-16 rounded-full flex items-center justify-center shadow-sm">
                  {feature.icon}
                </div>
                <h3 className="mt-4 text-xl font-semibold text-gray-900">{feature.title}</h3>
                <p className="mt-2 text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-green-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white">Ready to Transform Your Farming Business?</h2>
            <p className="mt-4 text-lg text-green-200">Join thousands of farmers who are already benefiting from our platform</p>
            <button className="mt-8 bg-white text-green-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
              Get Started Today
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">About Us</h3>
              <p className="text-sm">Empowering farmers with technology to create sustainable and profitable agriculture.</p>
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-green-400">For Farmers</a></li>
                <li><a href="#" className="hover:text-green-400">For Customers</a></li>
                <li><a href="#" className="hover:text-green-400">Market Insights</a></li>
                <li><a href="#" className="hover:text-green-400">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Contact</h3>
              <ul className="space-y-2 text-sm">
                <li>Email: support@agritech.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Address: 123 Farming Street, Agritown</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-sm text-center">
            © 2025 AgriTech Solutions. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;